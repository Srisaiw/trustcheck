// Background service worker to simulate AI analysis
// In a real application, this would make an API call to a backend running an LLM like Gemini or Claude.

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "analyze_product") {
    // Simulate API delay
    setTimeout(() => {
      const analysis = mockAiAnalysis(request.data);
      sendResponse(analysis);
    }, 1500);
    return true; // Keep the message channel open for async response
  }
});

function mockAiAnalysis(data) {
  // Start with a neutral baseline
  let trustScore = 50; 
  let reasoning = [];
  
  // Platform Check
  if (data.platform === 'Amazon' || data.platform === 'Flipkart' || data.platform === 'Myntra' || data.platform === 'Ajio') {
    trustScore += 10;
    reasoning.push(`Major platform (${data.platform}) provides strong buyer protection and return policies.`);
  } else {
    trustScore -= 15;
    reasoning.push(`Platform (${data.platform}) provides limited verification. Higher risk.`);
  }

  // Seller Check
  if (data.platform === 'Myntra' || data.platform === 'Ajio') {
    trustScore += 20;
    reasoning.push(`${data.platform} strictly verifies its partnered brands ('${data.seller}'). High authenticity guarantee.`);
  } else if (data.seller && data.seller.toLowerCase() !== 'unknown') {
    let sellerLower = data.seller.toLowerCase();
    // Check for known official/mega sellers (Added Clicktech which is a major authorized Apple seller in India)
    if (sellerLower.includes('amazon') || sellerLower.includes('appario') || sellerLower.includes('retailnet') || sellerLower.includes('cocoblu') || sellerLower.includes('clicktech') || sellerLower.includes('supercomnet')) {
      trustScore += 20;
      reasoning.push(`Seller (${data.seller}) is an official or highly trusted authorized retail partner.`);
    } else {
      // Neutral score for 3rd party
      reasoning.push(`Third-party seller ('${data.seller}'). Authenticity heavily relies on product review volume.`);
    }
  } else {
    trustScore -= 25;
    reasoning.push(`Seller identity hidden or unknown. Massive red flag for scams or drop-shipping.`);
  }

  // Review Volume Check
  let reviewText = data.reviewCount || '';
  let parsedCount = parseInt(reviewText.replace(/[^0-9]/g, '')) || 0;
  let ratingNum = parseFloat(data.rating);
  
  if (isNaN(ratingNum) || parsedCount === 0) {
    if (data.platform === 'Myntra' || data.platform === 'Ajio') {
      reasoning.push(`No verified reviews found, but acceptable since ${data.platform} is a curated platform that relies on brand verification rather than user reviews.`);
    } else {
      trustScore -= 30;
      reasoning.push(`No verified reviews found. Extremely high risk for a fake, scam, or untested product on open marketplaces.`);
    }
  } else {
    if (parsedCount < 10) {
      trustScore -= 20;
      reasoning.push(`Only ${parsedCount} reviews. Dangerously low volume. Easy to fake ratings.`);
    } else if (parsedCount < 50) {
      trustScore -= 5;
      reasoning.push(`Low review volume (${parsedCount}). Read reviews carefully to ensure they aren't bots.`);
    } else if (parsedCount < 200) {
      trustScore += 10;
      reasoning.push(`Good review volume (${parsedCount}). Ratings are likely authentic.`);
    } else if (parsedCount < 1000) {
      trustScore += 20;
      reasoning.push(`Very strong review volume (${parsedCount}). High confidence in rating authenticity.`);
    } else {
      trustScore += 30;
      reasoning.push(`Massive review volume (${parsedCount}+). This is a well-established, genuine listing.`);
    }

    // Rating value check
    if (ratingNum >= 4.5) {
      trustScore += 15;
      reasoning.push(`Excellent overall rating (${data.rating}⭐).`);
    } else if (ratingNum >= 4.0) {
      trustScore += 10;
      reasoning.push(`Solid overall rating (${data.rating}⭐).`);
    } else if (ratingNum < 3.5) {
      trustScore -= 20;
      reasoning.push(`Poor overall rating (${data.rating}⭐). Frequent buyer complaints reported.`);
    }
  }

  // Title Scam Heuristics
  if (data.title) {
    let lowerTitle = data.title.toLowerCase();
    if (lowerTitle.length > 120) {
      trustScore -= 10;
      reasoning.push(`Product title is excessively stuffed with keywords, typical of cheap knock-off items.`);
    }
    
    // Check for scam words
    if (lowerTitle.includes('[original]') || lowerTitle.includes('100% genuine')) {
      trustScore -= 20;
      reasoning.push(`Legitimate brands rarely use tags like "[Original]" or "100% Genuine". This is highly indicative of a fake.`);
    }

    // Common misspelling scams (e.g., Budss, CMFF)
    const typoRegex = /\b(budss|cmff|airpodds|iphonn|sammsung|appple)\b/i;
    if (typoRegex.test(lowerTitle)) {
      trustScore -= 30;
      reasoning.push(`Title contains suspicious brand misspellings (e.g., Budss, CMFF). This is a confirmed counterfeit technique.`);
    }
  }

  // Discount Check
  let discountNum = 0;
  if (data.discount) {
    discountNum = parseInt(data.discount.replace(/[^0-9]/g, '')) || 0;
  }
  
  if (discountNum > 60 && parsedCount < 50) {
    trustScore -= 25;
    reasoning.push(`Massive discount (${discountNum}%) with almost no reviews. Extremely common tactic for fake listings to attract impulse buyers.`);
  } else if (discountNum > 70) {
    trustScore -= 10;
    reasoning.push(`Suspiciously high discount (${discountNum}%). Too good to be true for genuine electronics.`);
  }

  // Cap score strictly between 1 and 99
  trustScore = Math.max(1, Math.min(99, trustScore));

  return {
    trustScore,
    reasoning: reasoning.join(" ")
  };
}
