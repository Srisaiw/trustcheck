document.addEventListener('DOMContentLoaded', () => {
  const analyzeBtn = document.getElementById('analyze-btn');
  const resetBtn   = document.getElementById('reset-btn');
  const retryBtn   = document.getElementById('retry-btn');
  const themeBtn   = document.getElementById('theme-toggle');
  const themeIcon  = document.getElementById('theme-icon');

  const states = {
    initial: document.getElementById('initial-state'),
    loading: document.getElementById('loading-state'),
    result:  document.getElementById('result-state'),
    error:   document.getElementById('error-state')
  };

  // ── Theme (persisted) ─────────────────────────────────────────────
  applyTheme(localStorage.getItem('tc-theme') || 'dark');

  themeBtn.addEventListener('click', () => {
    const next = document.body.classList.contains('light') ? 'dark' : 'light';
    applyTheme(next);
    localStorage.setItem('tc-theme', next);
  });

  function applyTheme(theme) {
    document.body.classList.toggle('light', theme === 'light');
    themeIcon.textContent = theme === 'light' ? '🌙' : '☀️';
  }

  // ── State switching ───────────────────────────────────────────────
  function switchState(name) {
    Object.values(states).forEach(s => s.classList.remove('active'));
    states[name].classList.add('active');
  }

  analyzeBtn.addEventListener('click', analyzeProduct);
  resetBtn.addEventListener('click',   () => switchState('initial'));
  retryBtn.addEventListener('click',   () => switchState('initial'));

  // ── Analysis flow ─────────────────────────────────────────────────
  async function analyzeProduct() {
    switchState('loading');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) { showError('Cannot access the current tab.'); return; }

    chrome.scripting.executeScript(
      { target: { tabId: tab.id }, files: ['content.js'] },
      () => {
        chrome.tabs.sendMessage(tab.id, { action: 'extract_product_data' }, (response) => {
          if (chrome.runtime.lastError || !response || response.error) {
            showError('Could not find product information on this page. Make sure you\'re on a supported product page (Amazon, Flipkart, Myntra, Ajio, eBay).');
            return;
          }
          chrome.runtime.sendMessage({ action: 'analyze_product', data: response.data }, (analysis) => {
            if (chrome.runtime.lastError || !analysis) {
              showError('AI Analysis failed. Please try again.');
              return;
            }
            showResult(response.data, analysis);
          });
        });
      }
    );
  }

  function showError(msg) {
    document.getElementById('error-message').textContent = msg;
    switchState('error');
  }

  // ── Helpers ───────────────────────────────────────────────────────
  function renderStars(stars) {
    const full  = Math.floor(stars);
    const half  = (stars % 1) >= 0.5 ? 1 : 0;
    const empty = 5 - full - half;
    return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
  }

  function starClass(stars) {
    if (stars > 3.5) return 'stars-good';
    if (stars > 2)   return 'stars-warn';
    return 'stars-bad';
  }

  function barClass(stars) {
    if (stars > 3.5) return 'bar-good';
    if (stars > 2)   return 'bar-warn';
    return 'bar-bad';
  }

  // Fill one DR column (delivery / returns / refund)
  function fillDRCol(prefix, item) {
    // Badge
    const badge = document.getElementById(`${prefix}-badge`);
    badge.textContent = item.label;
    badge.className   = `dr-badge badge-${item.status}`;

    // Status dot
    const dot = document.getElementById(`${prefix}-dot`);
    dot.className = `dr-status-dot dot-${item.status}`;

    // Note
    document.getElementById(`${prefix}-note`).textContent = item.note;

    // Stars + label
    if (item.stars !== undefined) {
      const starsEl    = document.getElementById(`${prefix}-stars`);
      const starsLabel = document.getElementById(`${prefix}-stars-label`);
      starsEl.textContent    = renderStars(item.stars);
      starsLabel.textContent = `${item.stars} / 5`;
      starsEl.className      = `dr-stars ${starClass(item.stars)}`;

      // Animate progress bar (delayed so transition fires)
      const bar = document.getElementById(`${prefix}-bar`);
      if (bar) {
        bar.className = `dr-bar-fill ${barClass(item.stars)}`;
        setTimeout(() => {
          bar.style.width = `${(item.stars / 5) * 100}%`;
        }, 120);
      }
    }
  }

  // ── Main result renderer ──────────────────────────────────────────
  function showResult(data, analysis) {
    // Product meta
    const titleEl = document.getElementById('product-title');
    titleEl.textContent = data.title || 'Unknown Product';
    titleEl.title       = data.title || '';
    document.getElementById('seller-name').textContent = data.seller || 'Unknown Seller';

    let reviewText = 'No reviews available';
    if (data.rating && data.reviewCount) reviewText = `${data.rating} ⭐  (${data.reviewCount} reviews)`;
    else if (data.rating)                reviewText = `${data.rating} ⭐`;
    document.getElementById('review-stats').textContent = reviewText;

    // Trust score circle
    const score     = analysis.trustScore;
    const circle    = document.getElementById('score-circle');
    const scoreText = document.getElementById('score-text');
    const verdictEl = document.getElementById('verdict-text');

    setTimeout(() => { circle.setAttribute('stroke-dasharray', `${score}, 100`); }, 120);
    scoreText.textContent = `${score}%`;
    document.getElementById('ai-reasoning').textContent = analysis.reasoning;

    // Verdict + colour
    verdictEl.className = 'verdict';
    if (score >= 80) {
      circle.style.stroke = '#10b981';
      verdictEl.textContent = 'Highly Trusted';
      verdictEl.classList.add('safe');
    } else if (score >= 50) {
      circle.style.stroke = '#f59e0b';
      verdictEl.textContent = 'Proceed with Caution';
      verdictEl.classList.add('warning');
    } else {
      circle.style.stroke = '#ef4444';
      verdictEl.textContent = 'High Risk';
      verdictEl.classList.add('danger');
    }

    // Delivery & Returns columns
    if (analysis.delivery) {
      fillDRCol('delivery', analysis.delivery.delivery);
      fillDRCol('returns',  analysis.delivery.returns);
      fillDRCol('refund',   analysis.delivery.refund);
    }

    switchState('result');
  }
});
