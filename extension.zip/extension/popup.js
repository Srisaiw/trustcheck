document.addEventListener('DOMContentLoaded', () => {
  const analyzeBtn = document.getElementById('analyze-btn');
  const resetBtn = document.getElementById('reset-btn');
  const retryBtn = document.getElementById('retry-btn');
  
  const states = {
    initial: document.getElementById('initial-state'),
    loading: document.getElementById('loading-state'),
    result: document.getElementById('result-state'),
    error: document.getElementById('error-state')
  };

  function switchState(stateName) {
    Object.values(states).forEach(state => state.classList.remove('active'));
    states[stateName].classList.add('active');
  }

  analyzeBtn.addEventListener('click', analyzeProduct);
  resetBtn.addEventListener('click', () => switchState('initial'));
  retryBtn.addEventListener('click', () => switchState('initial'));

  async function analyzeProduct() {
    switchState('loading');
    
    // Get current active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab) {
      showError("Cannot access the current tab.");
      return;
    }

    // Execute content script to scrape data
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    }, () => {
      // Send a message to the content script asking for data
      chrome.tabs.sendMessage(tab.id, { action: "extract_product_data" }, (response) => {
        if (chrome.runtime.lastError || !response || response.error) {
          showError("Could not find product information on this page. Make sure you are on a supported product page (like Amazon, eBay, etc).");
          return;
        }
        
        // Pass the scraped data to background for AI analysis
        chrome.runtime.sendMessage({ action: "analyze_product", data: response.data }, (analysis) => {
          if (chrome.runtime.lastError || !analysis) {
            showError("AI Analysis failed. Please try again.");
            return;
          }
          
          showResult(response.data, analysis);
        });
      });
    });
  }

  function showError(msg) {
    document.getElementById('error-message').textContent = msg;
    switchState('error');
  }

  function showResult(data, analysis) {
    // Update basic info
    document.getElementById('product-title').textContent = data.title || 'Unknown Product';
    document.getElementById('product-title').title = data.title || '';
    
    document.getElementById('seller-name').textContent = data.seller || 'Unknown Seller';
    
    let reviewText = 'No reviews';
    if (data.rating && data.reviewCount) {
      reviewText = `${data.rating} ⭐ (${data.reviewCount})`;
    } else if (data.rating) {
      reviewText = `${data.rating} ⭐`;
    }
    document.getElementById('review-stats').textContent = reviewText;

    // Update AI Analysis
    const score = analysis.trustScore; // 0-100
    const circle = document.getElementById('score-circle');
    const scoreText = document.getElementById('score-text');
    const verdictEl = document.getElementById('verdict-text');
    
    // Animate circle
    setTimeout(() => {
      circle.setAttribute('stroke-dasharray', `${score}, 100`);
    }, 100);
    
    scoreText.textContent = `${score}%`;
    document.getElementById('ai-reasoning').textContent = analysis.reasoning;

    // Colors and Verdict
    verdictEl.className = 'verdict'; // reset
    if (score >= 80) {
      circle.style.stroke = '#10b981'; // success
      verdictEl.textContent = 'Highly Trusted';
      verdictEl.classList.add('safe');
    } else if (score >= 50) {
      circle.style.stroke = '#f59e0b'; // warning
      verdictEl.textContent = 'Proceed with Caution';
      verdictEl.classList.add('warning');
    } else {
      circle.style.stroke = '#ef4444'; // danger
      verdictEl.textContent = 'High Risk / Suspicious';
      verdictEl.classList.add('danger');
    }

    switchState('result');
  }
});
